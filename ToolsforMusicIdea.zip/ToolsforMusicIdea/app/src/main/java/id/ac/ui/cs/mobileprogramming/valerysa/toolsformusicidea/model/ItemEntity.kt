package id.ac.ui.cs.mobileprogramming.valerysa.toolsformusicidea.model

import java.util.*

interface ItemEntity {
    fun getType():Int
    fun getTimeStamp():Date
}