package id.ac.ui.cs.mobileprogramming.valerysa.toolsformusicidea.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

data class NewsEntity(
    var url: String,
    var title: String
)